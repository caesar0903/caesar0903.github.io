import { Component,ElementRef, ViewChild} from '@angular/core';
import { faEye , faEyeSlash } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.scss']
})
export class UserLoginComponent {
  public accountNumber:string='';
  public userName:string='';
  public password:string='';
  public checkStorage:boolean=false;

  public accountEye = faEye
  public userEye = faEye
  public passwordEye = faEyeSlash

  //public checkEye = document.getElementById("checkEye");
  //public floatingPassword =  document.getElementById("floatingPassword") || {}};
  @ViewChild('floatingPassword') floatingPassword: ElementRef | undefined;
  @ViewChild('checkEye') checkEye: ElementRef | undefined;
  

  constructor() {
    
  }
  public showPsw() {
    console.log(this.floatingPassword?.nativeElement?.type)
    debugger
    if(this.floatingPassword) {
      if(this.passwordEye === faEyeSlash) {
        this.floatingPassword.nativeElement.type = 'password';
      }else if(this.passwordEye === faEye) {
        this.floatingPassword.nativeElement.type = 'text';
      }
      
    }
    if(this.passwordEye === faEyeSlash) {
      this.passwordEye = faEye;
    }else {
      this.passwordEye = faEyeSlash;
    }
    //this.floatingPassword.setAttribute('type','text')
  }
}
